def print_lol(the_list):
    for each_item in the_list:
        if isinstance(each_item,list):
            print("inside if ")
            print_lol(each_item)
        else:
            print("Inside else")
            print(each_item)


